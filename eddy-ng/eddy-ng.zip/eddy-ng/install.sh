#!/bin/bash
exec python3 install.py $*

